package com.example.commandnpc;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class CommandNpcMod implements ModInitializer {
    public static final String MODID = "commandnpc";
    private static final Logger LOGGER = LoggerFactory.getLogger(MODID);

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type NPC_MAP_TYPE = new TypeToken<Map<String, NpcData>>() {}.getType();
    private static final Type SKIN_MAP_TYPE = new TypeToken<Map<String, SkinCache>>() {}.getType();

    private static final HttpClient HTTP = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10))
        .followRedirects(HttpClient.Redirect.NORMAL)
        .build();

    public static final Map<String, NpcData> NPCS = new HashMap<>();
    public static final Map<String, SkinCache> SKINS = new HashMap<>();

    private static Path npcFile;
    private static Path skinsFile;

    /** per-npc per-player cooldown timestamps */
    private static final Map<String, Map<UUID, Long>> LAST_USE = new ConcurrentHashMap<>();
    private static final Map<String, Map<UUID, Long>> LAST_CLICK_TICK = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        CommandNpcRegistry.register();

        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) -> dispatcher.register(
            literal("cnpc")
                .then(literal("create")
                    .then(argument("id", StringArgumentType.word())
                        .then(argument("displayName", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                if (!isAdmin(ctx.getSource())) { ctx.getSource().sendError(Text.literal("No permission (need cnpc.admin).")); return 0; }
                                createNpc(ctx.getSource(), StringArgumentType.getString(ctx, "id"), StringArgumentType.getString(ctx, "displayName"));
                                return 1;
                            }))))
                .then(literal("setlabel")
    .then(argument("id", StringArgumentType.word())
        .suggests((ctx,b)->{ initPaths(ctx.getSource().getServer()); for(String k: NPCS.keySet()) b.suggest(k); return b.buildFuture(); })
        .then(argument("mini", StringArgumentType.greedyString())
            .executes(ctx -> {
                var src = ctx.getSource();
                if (!isAdmin(src)) return 0;
                String id = StringArgumentType.getString(ctx, "id");
                String mini = StringArgumentType.getString(ctx, "mini");
                NpcData d = NPCS.get(id);
                if (d == null) { src.sendError(Text.literal("NPC not found: " + id)); return 0; }
                d.labelMini = mini;
                normalizeNpcData(d);
                save(src.getServer());
                var e = findNpcEntity(src.getServer(), id);
                if (e != null) applyLabel(e, d);
                src.sendFeedback(() -> Text.literal("Set label for " + id), false);
                return 1;
            })
        )
    )
)
        .then(literal("setcmd")
                    .then(argument("id", StringArgumentType.word())
                        .then(argument("cmd", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                if (!isAdmin(ctx.getSource())) { ctx.getSource().sendError(Text.literal("No permission (need cnpc.admin).")); return 0; }
                                initPaths(ctx.getSource().getServer());
                                var id = StringArgumentType.getString(ctx, "id");
                                var cmd = StringArgumentType.getString(ctx, "cmd");
                                var d = NPCS.get(id);
                                if (d == null) { ctx.getSource().sendError(Text.literal("No NPC with id: " + id)); return 0; }
                                d.command = cmd;
                                save(ctx.getSource().getServer());
                                final String msg = "Set command for " + id + " -> " + cmd;
                                ctx.getSource().sendFeedback(() -> Text.literal(msg), false);
                                return 1;
                            }))))
                .then(literal("setperm")
                    .then(argument("id", StringArgumentType.word())
                        .then(argument("perm", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                if (!isAdmin(ctx.getSource())) { ctx.getSource().sendError(Text.literal("No permission (need cnpc.admin).")); return 0; }
                                initPaths(ctx.getSource().getServer());
                                var id = StringArgumentType.getString(ctx, "id");
                                var perm = StringArgumentType.getString(ctx, "perm");
                                var d = NPCS.get(id);
                                if (d == null) { ctx.getSource().sendError(Text.literal("No NPC with id: " + id)); return 0; }
                                d.usePermission = perm;
                                save(ctx.getSource().getServer());
                                final String msg = "Set permission for " + id + " -> " + perm;
                                ctx.getSource().sendFeedback(() -> Text.literal(msg), false);
                                return 1;
                            }))))
                .then(literal("setcooldown")
                    .then(argument("id", StringArgumentType.word())
                        .then(argument("seconds", IntegerArgumentType.integer(0, 86400))
                            .executes(ctx -> {
                                if (!isAdmin(ctx.getSource())) { ctx.getSource().sendError(Text.literal("No permission (need cnpc.admin).")); return 0; }
                                initPaths(ctx.getSource().getServer());
                                var id = StringArgumentType.getString(ctx, "id");
                                var sec = IntegerArgumentType.getInteger(ctx, "seconds");
                                var d = NPCS.get(id);
                                if (d == null) { ctx.getSource().sendError(Text.literal("No NPC with id: " + id)); return 0; }
                                d.cooldownSeconds = sec;
                                save(ctx.getSource().getServer());
                                final String msg = "Set cooldown for " + id + " -> " + sec + "s";
                                ctx.getSource().sendFeedback(() -> Text.literal(msg), false);
                                return 1;
                            }))))
                .then(literal("skinhash")
                    .then(argument("id", StringArgumentType.word())
                        .then(argument("hash", StringArgumentType.word())
                            .executes(ctx -> {
                                if (!isAdmin(ctx.getSource())) { ctx.getSource().sendError(Text.literal("No permission (need cnpc.admin).")); return 0; }
                                setSkinHash(ctx.getSource(), StringArgumentType.getString(ctx, "id"), StringArgumentType.getString(ctx, "hash"));
                                return 1;
                            }))))
                .then(literal("skin")
                    .then(argument("id", StringArgumentType.word())
                        .then(argument("player", StringArgumentType.word())
                            .executes(ctx -> {
                                if (!isAdmin(ctx.getSource())) { ctx.getSource().sendError(Text.literal("No permission (need cnpc.admin).")); return 0; }
                                setSkinFromPlayer(ctx.getSource(), StringArgumentType.getString(ctx, "id"), StringArgumentType.getString(ctx, "player"));
                                return 1;
                            }))))
                .then(literal("remove")
                    .then(argument("id", StringArgumentType.word())
                        .executes(ctx -> {
                            if (!isAdmin(ctx.getSource())) { ctx.getSource().sendError(Text.literal("No permission (need cnpc.admin).")); return 0; }
                            removeNpc(ctx.getSource(), StringArgumentType.getString(ctx, "id"));
                            return 1;
                        })))
                .then(literal("list").executes(ctx -> {
                    if (!isAdmin(ctx.getSource())) { ctx.getSource().sendError(Text.literal("No permission (need cnpc.admin).")); return 0; }
                    initPaths(ctx.getSource().getServer());
                    if (NPCS.isEmpty()) { ctx.getSource().sendFeedback(() -> Text.literal("No NPCs."), false); return 1; }
                    ctx.getSource().sendFeedback(() -> Text.literal("NPCs: " + String.join(", ", NPCS.keySet())), false);
                    return 1;
                }))
        ));

        // Right-click handling (server)
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient()) return ActionResult.PASS;
            if (hand != Hand.MAIN_HAND) return ActionResult.PASS;
            if (!(entity instanceof CommandNpcEntity npc)) return ActionResult.PASS;

            initPaths(world.getServer());
            NpcData data = NPCS.get(npc.getNpcId());
            if (data == null) return ActionResult.PASS;

            if (!(player instanceof ServerPlayerEntity sp)) return ActionResult.PASS;

            // Debounce: prevent duplicate triggers from one click (same tick)
            long tick = world.getTime();
            long lastTick = LAST_CLICK_TICK.computeIfAbsent(data.id, k -> new ConcurrentHashMap<>())
                .getOrDefault(sp.getUuid(), Long.MIN_VALUE);
            if (lastTick == tick) return ActionResult.CONSUME;
            LAST_CLICK_TICK.get(data.id).put(sp.getUuid(), tick);

            if (!canUse(sp, data)) {
                sp.sendMessage(Text.translatable("commandnpc.msg.no_perm"), true);
                return ActionResult.FAIL;
            }

            int remaining = getCooldownRemainingSeconds(sp, data);
            if (remaining > 0 && !hasCooldownBypass(sp)) {
                String formatted = formatDuration(remaining);
                sp.sendMessage(Text.translatable("commandnpc.msg.cooldown", formatted), false);
                return ActionResult.CONSUME;
            }

            markUsed(sp, data);
            executeNpcCommand(sp, data);
            return ActionResult.CONSUME;
        });

        // Look at nearest player (server) by setting yaw on entity
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            try {
                initPaths(server);

                // Keep NPCs alive across chunk unloads/restarts
                long t = server.getOverworld().getTime();
                if (t % 40 == 0) {
                    respawnMissingNpcs(server);
                }
                for (ServerWorld w : server.getWorlds()) {
                    for (Entity e : w.iterateEntities()) {
                        if (!(e instanceof CommandNpcEntity npc)) continue;
                        ServerPlayerEntity nearest = findNearestPlayer(w, npc.getPos(), 10.0);
                        if (nearest == null) continue;
                        npc.lookAt(nearest.getEyePos());
                    }
                }
            } catch (Throwable ignored) {}
        });
    }


private static boolean hasPermission(ServerPlayerEntity player, String permission, int fallbackLevel) {
    // Try Fabric Permissions API if installed (server-side). If not, fall back to OP level.
    try {
        Class<?> perms = Class.forName("me.lucko.fabric.api.permissions.v0.Permissions");
        var m = perms.getMethod("check", ServerPlayerEntity.class, String.class, int.class);
        Object r = m.invoke(null, player, permission, fallbackLevel);
        return r instanceof Boolean b ? b : (boolean) r;
    } catch (Throwable ignored) {
        return player.hasPermissionLevel(fallbackLevel);
    }
}


private static CommandNpcEntity findNpcEntity(net.minecraft.server.MinecraftServer server, String id) {
    if (server == null || id == null) return null;
    for (var world : server.getWorlds()) {
        for (var e : world.iterateEntities()) {
            if (e instanceof CommandNpcEntity npc && id.equals(npc.getNpcId())) return npc;
        }
    }
    return null;
}

    private static boolean isAdmin(ServerCommandSource src) {
        if (src.getEntity() instanceof ServerPlayerEntity p) {
            return src.hasPermissionLevel(2) || hasPermission(p, "cnpc.admin", 2);
        }
        return true;
    }

    public static boolean hasCooldownBypass(ServerPlayerEntity player) {
        return hasPermission(player, "cnpc.bypass.cooldown", 0);
    }

    public static boolean canUse(ServerPlayerEntity player, NpcData data) {
        String perm = (data.usePermission == null || data.usePermission.isBlank())
            ? ("cnpc.use." + data.id)
            : data.usePermission;
        return hasPermission(player, perm, 0);
    }

    public static String formatDuration(int totalSeconds) {
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;
        StringBuilder sb = new StringBuilder();
        if (hours > 0) sb.append(hours).append("h ");
        if (minutes > 0 || hours > 0) sb.append(minutes).append("m ");
        sb.append(seconds).append("s");
        return sb.toString().trim();
    }

    private static int getCooldownRemainingSeconds(ServerPlayerEntity player, NpcData data) {
        int cd = Math.max(0, data.cooldownSeconds);
        if (cd == 0) return 0;

        long now = System.currentTimeMillis();
        long last = LAST_USE.computeIfAbsent(data.id, k -> new ConcurrentHashMap<>())
            .getOrDefault(player.getUuid(), 0L);

        long elapsed = now - last;
        long cdMs = cd * 1000L;
        if (elapsed >= cdMs) return 0;
        long remainingMs = cdMs - elapsed;
        return (int)Math.ceil(remainingMs / 1000.0);
    }

    private static void markUsed(ServerPlayerEntity player, NpcData data) {
        LAST_USE.computeIfAbsent(data.id, k -> new ConcurrentHashMap<>())
            .put(player.getUuid(), System.currentTimeMillis());
    }


// Very small "MiniMessage-like" parser:
// Supports tags like <white>, <red>, <gold>, <yellow>, <green>, <aqua>, <blue>, <light_purple>, <gray>, <dark_gray>, <black>
// and styles <bold>, <italic>, <underlined>, <strikethrough>, <obfuscated>, <reset>.
// Example: <bold><white>Hello <red>world!
private static Text parseMini(String mini) {
    if (mini == null) return Text.empty();
    java.util.EnumSet<net.minecraft.util.Formatting> active = java.util.EnumSet.noneOf(net.minecraft.util.Formatting.class);
    java.util.ArrayList<net.minecraft.text.MutableText> parts = new java.util.ArrayList<>();
    StringBuilder buf = new StringBuilder();
    int i = 0;
    while (i < mini.length()) {
        char c = mini.charAt(i);
        if (c == '<') {
            int end = mini.indexOf('>', i + 1);
            if (end > i) {
                if (!buf.isEmpty()) {
                    var t = Text.literal(buf.toString());
                    if (!active.isEmpty()) t = t.formatted(active.toArray(new net.minecraft.util.Formatting[0]));
                    parts.add(t);
                    buf.setLength(0);
                }
                String tag = mini.substring(i + 1, end).trim().toUpperCase();
                if (tag.startsWith("/")) { active.clear(); i = end + 1; continue; }
                if (tag.equals("RESET")) { active.clear(); i = end + 1; continue; }
                try {
                    net.minecraft.util.Formatting f = net.minecraft.util.Formatting.valueOf(tag);
                    if (f == net.minecraft.util.Formatting.RESET) active.clear();
                    else {
                        if (f.isColor()) active.removeIf(net.minecraft.util.Formatting::isColor);
                        active.add(f);
                    }
                } catch (Exception ignored) {
                    buf.append('<').append(mini, i + 1, end).append('>');
                }
                i = end + 1;
                continue;
            }
        }
        buf.append(c);
        i++;
    }
    if (!buf.isEmpty()) {
        var t = Text.literal(buf.toString());
        if (!active.isEmpty()) t = t.formatted(active.toArray(new net.minecraft.util.Formatting[0]));
        parts.add(t);
    }
    if (parts.isEmpty()) return Text.empty();
    var out = parts.get(0);
    for (int p = 1; p < parts.size(); p++) out.append(parts.get(p));
    return out;
}

private static void applyLabel(CommandNpcEntity npc, NpcData data) {
    normalizeNpcData(data);
    npc.setCustomName(parseMini(data.labelMini));
    npc.setCustomNameVisible(true);
}

    private static void executeNpcCommand(ServerPlayerEntity clicker, NpcData data) {
        String cmd = data.command == null ? "" : data.command.trim();
        if (cmd.isEmpty()) return;

        cmd = cmd.replace("{player}", clicker.getName().getString());
        if (cmd.startsWith("/")) cmd = cmd.substring(1);

        clicker.getServer().getCommandManager().executeWithPrefix(
            clicker.getServer().getCommandSource(),
            cmd
        );
    }

    private static ServerPlayerEntity findNearestPlayer(ServerWorld world, Vec3d from, double range) {
        double best = range * range;
        ServerPlayerEntity bestP = null;
        for (ServerPlayerEntity p : world.getPlayers()) {
            double d2 = p.squaredDistanceTo(from);
            if (d2 < best) { best = d2; bestP = p; }
        }
        return bestP;
    }

private static ServerWorld getWorldByKey(MinecraftServer server, String worldKey) {
    try {
        Identifier id = Identifier.tryParse(worldKey);
        if (id == null) return null;
        RegistryKey<net.minecraft.world.World> key = RegistryKey.of(RegistryKeys.WORLD, id);
        return server.getWorld(key);
    } catch (Throwable t) {
        return null;
    }
}

private static boolean isPlayerNear(ServerWorld world, double x, double y, double z, double range) {
    double r2 = range * range;
    Vec3d p = new Vec3d(x, y, z);
    for (ServerPlayerEntity sp : world.getPlayers()) {
        if (sp.squaredDistanceTo(p) <= r2) return true;
    }
    return false;
}

private static void respawnMissingNpcs(MinecraftServer server) {
    // ensure labelMini defaults exist
    NPCS.values().forEach(CommandNpcMod::normalizeNpcData);

    for (NpcData d : NPCS.values()) {
        if (d == null || d.id == null || d.id.isBlank()) continue;

        CommandNpcEntity existing = findNpcEntity(server, d.id);
        if (existing != null) {
            // keep live entity synced
            if (d.skinHash != null && !d.skinHash.isBlank()) existing.setSkinHash(d.skinHash);
            applyLabel(existing, d);
            continue;
        }

        ServerWorld w = getWorldByKey(server, d.worldKey);
        if (w == null) continue;

        BlockPos bp = BlockPos.ofFloored(d.x, d.y, d.z);

        // Don't force-load chunks; only respawn when loaded and a player is near
        if (!w.isChunkLoaded(bp)) continue;
        if (!isPlayerNear(w, d.x, d.y, d.z, 96.0)) continue;

        CommandNpcEntity npc = new CommandNpcEntity(CommandNpcRegistry.NPC_ENTITY, w);
        npc.refreshPositionAndAngles(d.x, d.y, d.z, d.yaw, d.pitch);
        npc.setNpcId(d.id);
        npc.setNpcDisplayName(d.displayName == null ? "NPC" : d.displayName);
        npc.setSkinHash(d.skinHash == null ? "" : d.skinHash);
        applyLabel(npc, d);

        w.spawnEntity(npc);

        // new entity => update UUID in saved data
        d.uuid = npc.getUuidAsString();
        save(server);
    }
}

    private static Path getRunDirPath(MinecraftServer server) {
        try {
            Object o = server.getRunDirectory();
            if (o instanceof Path p) return p;
            if (o instanceof java.io.File f) return f.toPath();
        } catch (Throwable ignored) {}
        return Path.of(".");
    }

    public static void initPaths(MinecraftServer server) {
        if (npcFile != null && skinsFile != null) return;
        Path dir = getRunDirPath(server).resolve("config").resolve("commandnpc");
        try { Files.createDirectories(dir); } catch (Exception ignored) {}
        npcFile = dir.resolve("npcs.json");
        skinsFile = dir.resolve("skins.json");
        load(server);
    }


private static void normalizeNpcData(NpcData d) {
    if (d == null) return;
    if (d.labelMini == null || d.labelMini.isBlank()) {
        d.labelMini = "<white>" + (d.displayName == null ? "" : d.displayName);
    }
}

    private static void load(MinecraftServer server) {
        if (npcFile != null && Files.exists(npcFile)) {
            try {
                Map<String, NpcData> m = GSON.fromJson(Files.readString(npcFile), NPC_MAP_TYPE);
                NPCS.clear();
                if (m != null) NPCS.putAll(m);
            } catch (Exception e) {
                LOGGER.error("[commandnpc] Failed to load NPCs", e);
            }
        }
        if (skinsFile != null && Files.exists(skinsFile)) {
            try {
                Map<String, SkinCache> m = GSON.fromJson(Files.readString(skinsFile), SKIN_MAP_TYPE);
                SKINS.clear();
                if (m != null) SKINS.putAll(m);
            } catch (Exception e) {
                LOGGER.error("[commandnpc] Failed to load skins cache", e);
            }
        }
    }

    private static void save(MinecraftServer server) {
        try {
            if (npcFile != null) Files.writeString(npcFile, GSON.toJson(NPCS, NPC_MAP_TYPE));
            if (skinsFile != null) Files.writeString(skinsFile, GSON.toJson(SKINS, SKIN_MAP_TYPE));
        } catch (Exception e) {
            LOGGER.error("[commandnpc] Failed to save config", e);
        }
    }

    private static void createNpc(ServerCommandSource src, String id, String displayName) {
        try {
            MinecraftServer server = src.getServer();
            initPaths(server);

            if (NPCS.containsKey(id)) { src.sendError(Text.literal("NPC id already exists: " + id)); return; }

            ServerWorld world = src.getWorld();
            Vec3d pos = src.getPosition();
            float yaw = src.getPlayer() != null ? src.getPlayer().getYaw() : 0f;
            float pitch = src.getPlayer() != null ? src.getPlayer().getPitch() : 0f;

            CommandNpcEntity npc = new CommandNpcEntity(CommandNpcRegistry.NPC_ENTITY, world);
            npc.refreshPositionAndAngles(pos.x, pos.y, pos.z, yaw, pitch);
            npc.setNpcId(id);
            npc.setNpcDisplayName(displayName);
            world.spawnEntity(npc);
NpcData d = new NpcData();
            d.id = id;
            d.worldKey = world.getRegistryKey().getValue().toString();
            d.uuid = npc.getUuidAsString();
            d.displayName = displayName;
            d.labelMini = "<white>" + displayName;
            d.x = pos.x; d.y = pos.y; d.z = pos.z;
            d.yaw = yaw; d.pitch = pitch;
            d.command = "pokeheal {player}";
            d.usePermission = "cnpc.use." + id;
            d.cooldownSeconds = 0;
            d.skinHash = ""; // set later
            npc.setSkinHash(d.skinHash);
            applyLabel(npc, d);
            NPCS.put(id, d);
            save(server);

            src.sendFeedback(() -> Text.literal("Created NPC '" + id + "'. Set skin: /cnpc skin " + id + " <player> OR /cnpc skinhash " + id + " <hash>"), false);
        } catch (Exception e) {
            LOGGER.error("[commandnpc] /cnpc create failed", e);
            src.sendError(Text.literal("Create failed: " + e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage())));
        }
    }

    private static void removeNpc(ServerCommandSource src, String id) {
        MinecraftServer server = src.getServer();
        initPaths(server);

        NpcData d = NPCS.remove(id);
        if (d == null) { src.sendError(Text.literal("No NPC with id: " + id)); return; }

        // remove entity if loaded
        for (ServerWorld w : server.getWorlds()) {
            Entity e = w.getEntity(UUID.fromString(d.uuid));
            if (e != null) e.discard();
        }
        LAST_USE.remove(id);

        save(server);
        final String msg = "Removed NPC: " + id;
        src.sendFeedback(() -> Text.literal(msg), false);
    }

    private static void setSkinHash(ServerCommandSource src, String id, String hashArg) {
        try {
            MinecraftServer server = src.getServer();
            initPaths(server);

            NpcData d = NPCS.get(id);
            if (d == null) { src.sendError(Text.literal("No NPC with id: " + id)); return; }

            String hash = hashArg;
            if (hash.contains("/")) hash = hash.substring(hash.lastIndexOf('/') + 1);
            hash = hash.trim();

            d.skinHash = hash;
            save(server);

            // update live entity if loaded
            for (ServerWorld w : server.getWorlds()) {
                Entity e = w.getEntity(UUID.fromString(d.uuid));
                if (e instanceof CommandNpcEntity npc) npc.setSkinHash(hash);
            }

            final String msg = "Set skin for " + id + " -> " + hash;
            src.sendFeedback(() -> Text.literal(msg), false);
        } catch (Exception e) {
            LOGGER.error("[commandnpc] /cnpc skinhash failed", e);
            src.sendError(Text.literal("Skin failed: " + e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage())));
        }
    }

    private static void setSkinFromPlayer(ServerCommandSource src, String id, String playerName) {
        try {
            MinecraftServer server = src.getServer();
            initPaths(server);

            NpcData d = NPCS.get(id);
            if (d == null) { src.sendError(Text.literal("No NPC with id: " + id)); return; }

            String key = playerName.toLowerCase(Locale.ROOT);

            // fetch (or fallback to cache)
            SkinCache fetched = fetchSkinHashFromMojang(playerName);
            if (fetched == null) {
                SkinCache cached = SKINS.get(key);
                if (cached == null) {
                    src.sendError(Text.literal("Mojang unreachable and no cached skin exists for: " + playerName));
                    return;
                }
                fetched = cached;
                src.sendFeedback(() -> Text.literal("Mojang unreachable — using cached skin for " + playerName), false);
            } else {
                SKINS.put(key, fetched);
                save(server);
            }

            d.skinHash = fetched.hash;
            save(server);

            for (ServerWorld w : server.getWorlds()) {
                Entity e = w.getEntity(UUID.fromString(d.uuid));
                if (e instanceof CommandNpcEntity npc) npc.setSkinHash(fetched.hash);
            }

            final String msg = "Set skin for " + id + " -> " + playerName + " (hash cached)";
            src.sendFeedback(() -> Text.literal(msg), false);
        } catch (Exception e) {
            LOGGER.error("[commandnpc] /cnpc skin failed", e);
            src.sendError(Text.literal("Skin failed: " + e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage())));
        }
    }

    /** Fetch signed textures once, extract textures.minecraft.net hash. */
    private static SkinCache fetchSkinHashFromMojang(String username) {
        try {
            HttpRequest req1 = HttpRequest.newBuilder()
                .uri(URI.create("https://api.mojang.com/users/profiles/minecraft/" + username))
                .timeout(Duration.ofSeconds(10))
                .GET().build();
            HttpResponse<String> r1 = HTTP.send(req1, HttpResponse.BodyHandlers.ofString());
            if (r1.statusCode() != 200) return null;

            var o1 = JsonParser.parseString(r1.body()).getAsJsonObject();
            if (!o1.has("id")) return null;
            String id = o1.get("id").getAsString();

            HttpRequest req2 = HttpRequest.newBuilder()
                .uri(URI.create("https://sessionserver.mojang.com/session/minecraft/profile/" + id + "?unsigned=false"))
                .timeout(Duration.ofSeconds(10))
                .GET().build();
            HttpResponse<String> r2 = HTTP.send(req2, HttpResponse.BodyHandlers.ofString());
            if (r2.statusCode() != 200) return null;

            var o2 = JsonParser.parseString(r2.body()).getAsJsonObject();
            var props = o2.getAsJsonArray("properties");
            if (props == null) return null;

            for (var el : props) {
                var po = el.getAsJsonObject();
                if (po.has("name") && "textures".equals(po.get("name").getAsString()) && po.has("value")) {
                    String value = po.get("value").getAsString();
                    // decode base64 json and extract url
                    String json = new String(Base64.getDecoder().decode(value), java.nio.charset.StandardCharsets.UTF_8);
                    var tex = JsonParser.parseString(json).getAsJsonObject()
                        .getAsJsonObject("textures")
                        .getAsJsonObject("SKIN")
                        .get("url").getAsString();
                    // url like http://textures.minecraft.net/texture/<hash>
                    String hash = tex.substring(tex.lastIndexOf('/') + 1);
                    return new SkinCache(hash);
                }
            }
            return null;
        } catch (Exception e) {
            LOGGER.warn("[commandnpc] Mojang fetch failed for {}", username, e);
            return null;
        }
    }

    public static class NpcData {
        public String id;
        public String worldKey;
        public String uuid;

        // saved spawn location (for respawn after chunk unload/restart)
        public double x, y, z;
        public float yaw, pitch;

        public String displayName;
        public String labelMini; // supports tags like <bold><white>Click <red>to heal!
        public String command;
        public String usePermission;
        public int cooldownSeconds;
        public String skinHash;
    }

    public static class SkinCache {public static class SkinCache {
        public String hash;
        public SkinCache() {}
        public SkinCache(String hash) { this.hash = hash; }
    }
}
