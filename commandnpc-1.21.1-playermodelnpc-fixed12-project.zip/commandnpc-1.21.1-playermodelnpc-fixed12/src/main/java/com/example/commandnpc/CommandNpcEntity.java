package com.example.commandnpc;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.control.LookControl;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class CommandNpcEntity extends MobEntity {

    private static final TrackedData<String> NPC_ID = DataTracker.registerData(CommandNpcEntity.class, TrackedDataHandlerRegistry.STRING);
    private static final TrackedData<String> DISPLAY_NAME_STR = DataTracker.registerData(CommandNpcEntity.class, TrackedDataHandlerRegistry.STRING);
    private static final TrackedData<String> SKIN_HASH = DataTracker.registerData(CommandNpcEntity.class, TrackedDataHandlerRegistry.STRING);

    public CommandNpcEntity(EntityType<? extends MobEntity> type, World world) {
        super(type, world);
        this.setAiDisabled(true);
        this.setNoGravity(true);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(NPC_ID, "");
        builder.add(DISPLAY_NAME_STR, "NPC");
        builder.add(SKIN_HASH, "");
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        if (nbt.contains("NpcId")) setNpcId(nbt.getString("NpcId"));
        if (nbt.contains("DisplayName")) setNpcDisplayName(nbt.getString("DisplayName"));
        if (nbt.contains("SkinHash")) setSkinHash(nbt.getString("SkinHash"));
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putString("NpcId", getNpcId());
        nbt.putString("DisplayName", getNpcDisplayName());
        nbt.putString("SkinHash", getSkinHash());
    }

    @Override
    public void tick() {
        super.tick();
        // Freeze
        this.setVelocity(Vec3d.ZERO);
        this.setNoGravity(true);
    }

    public String getNpcId() { return dataTracker.get(NPC_ID); }
    public void setNpcId(String id) { dataTracker.set(NPC_ID, id == null ? "" : id); }

    public String getNpcDisplayName() { return dataTracker.get(DISPLAY_NAME_STR); }
    public void setNpcDisplayName(String name) {
        dataTracker.set(DISPLAY_NAME_STR, name == null ? "NPC" : name);
        this.setCustomName(Text.literal(getNpcDisplayName()));
        this.setCustomNameVisible(true);
    }

    public String getSkinHash() { return dataTracker.get(SKIN_HASH); }
    public void setSkinHash(String hash) { dataTracker.set(SKIN_HASH, hash == null ? "" : hash); }

    public void lookAt(Vec3d targetEyePos) {
        Vec3d from = this.getPos().add(0, this.getStandingEyeHeight(), 0);
        Vec3d dir = targetEyePos.subtract(from);

        double dx = dir.x;
        double dy = dir.y;
        double dz = dir.z;

        float yaw = (float)(MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0F;
        float pitch = (float)(-(MathHelper.atan2(dy, Math.sqrt(dx*dx + dz*dz)) * (180.0 / Math.PI)));

        this.setYaw(yaw);
        this.setPitch(pitch);
        this.setHeadYaw(yaw);
    }
}