package com.example.commandnpc.client;

import com.example.commandnpc.CommandNpcEntity;
import com.example.commandnpc.CommandNpcMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import net.minecraft.client.util.DefaultSkinHelper;

import java.io.InputStream;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Renders NPC with the full player model and a skin downloaded from textures.minecraft.net/texture/<hash>.
 * This requires the mod on client.
 */
public class CommandNpcRenderer extends LivingEntityRenderer<CommandNpcEntity, PlayerEntityModel<CommandNpcEntity>> {

    private static final Map<String, Identifier> SKIN_IDS = new ConcurrentHashMap<>();

    public CommandNpcRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<CommandNpcEntity>(ctx.getPart(net.minecraft.client.render.entity.model.EntityModelLayers.PLAYER), false), 0.5f);
}

    @Override
    public Identifier getTexture(CommandNpcEntity entity) {
        String hash = entity.getSkinHash();
        if (hash == null || hash.isBlank()) {
            return DefaultSkinHelper.getTexture();
        }
        return SKIN_IDS.computeIfAbsent(hash, CommandNpcRenderer::downloadAndRegisterSkin);
    }

    private static Identifier downloadAndRegisterSkin(String hash) {
        Identifier id = Identifier.of(CommandNpcMod.MODID, "skins/" + hash);
        MinecraftClient client = MinecraftClient.getInstance();

        client.execute(() -> {
            try {
                URL url = new URL("https://textures.minecraft.net/texture/" + hash);
                try (InputStream in = url.openStream()) {
                    NativeImage img = NativeImage.read(in);
                    NativeImageBackedTexture tex = new NativeImageBackedTexture(img);
                    client.getTextureManager().registerTexture(id, tex);
                }
            } catch (Exception e) {
                // If download fails, leave whatever texture is there (will be missing/no-op)
            }
        });

        return id;
    }
}
