package com.example.commandnpc.client;

import com.example.commandnpc.CommandNpcEntity;
import com.example.commandnpc.CommandNpcRegistry;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class CommandNpcClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(CommandNpcRegistry.NPC_ENTITY, CommandNpcRenderer::new);
    }
}
