package com.example.commandnpc;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;

public final class CommandNpcRegistry {
    private CommandNpcRegistry() {}

    public static EntityType<CommandNpcEntity> NPC_ENTITY;

    public static void register() {
        NPC_ENTITY = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(CommandNpcMod.MODID, "npc"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, CommandNpcEntity::new)
                .dimensions(EntityDimensions.fixed(0.6f, 1.8f))
                .trackRangeBlocks(64)
                .trackedUpdateRate(1)
                .build()
        );

        // Required for LivingEntity/MobEntity: prevents NPEs when attributes are accessed
        FabricDefaultAttributeRegistry.register(NPC_ENTITY, CommandNpcEntity.createAttributes());
    }
}
