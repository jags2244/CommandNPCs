CommandNPC (Fabric 1.21.1) - v2.1.2 (Player Model NPCs)

IMPORTANT:
- This version REQUIRES the mod on BOTH the SERVER and CLIENT.
- NPCs are a custom entity rendered with the full player model.
- Skins are stored as a texture hash (textures.minecraft.net/texture/<hash>).
  - You can set via NameMC hash directly (no Mojang).
  - Or set by player name (server fetches ONCE from Mojang, extracts hash, caches it).

Commands:
- /cnpc create <id> <displayName...>
- /cnpc setcmd <id> <command...>              (runs as console; use {player})
- /cnpc setperm <id> <perm...>
- /cnpc setcooldown <id> <seconds>            (86400 = 24h)
- /cnpc skinhash <id> <hash>                  (no Mojang)
- /cnpc skin <id> <playerName>                (Mojang once; falls back to cached)
- /cnpc remove <id>
- /cnpc list

Permissions:
- cnpc.admin
- cnpc.use.<id>
- cnpc.bypass.cooldown

Build:
1) Copy gradlew, gradlew.bat, and gradle/wrapper/gradle-wrapper.jar from any working Fabric template.
2) Run: .\gradlew.bat clean build

Output jar:
- build\libs\commandnpc-2.1.2.jar

Install:
- Put the jar in server /mods AND in your client /mods (or modpack).


Label:
  /cnpc setlabel <id> <mini>
  Example: /cnpc setlabel testnpc <bold><white>Click <red>to heal!
